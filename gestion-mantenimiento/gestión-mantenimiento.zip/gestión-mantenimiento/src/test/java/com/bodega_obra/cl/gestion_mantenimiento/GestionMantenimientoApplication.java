package com.bodega_obra.cl.gestion_mantenimiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionMantenimientoApplication {

  public static void main(String[] args) {
    SpringApplication.run(GestionMantenimientoApplication.class, args);
  }

}
